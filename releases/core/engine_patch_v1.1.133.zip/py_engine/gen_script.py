from google import genai
import time

# 1. Khởi tạo Client với API Key của bạn
client = genai.Client(api_key="AIzaSyAKYtnkpAY8kmtiSP_FN3U5JpbdPcoqQ8Y")

print("Đang tải video lên...")
# 2. Upload video lên Google Files API (hỗ trợ MP4, MOV, AVI...)
video_file = client.files.upload(file="resources/tech/src/gen-001.mp4")
print(f"Đã upload xong. File URI: {video_file.uri}")

# 3. Chờ Google xử lý video (với video dài)
while video_file.state.name == "PROCESSING":
    print("Đang xử lý video...")
    time.sleep(5)
    video_file = client.files.get(name=video_file.name)

if video_file.state.name == "FAILED":
    raise ValueError("Xử lý video thất bại.")

# 4. Viết Prompt yêu cầu tạo kịch bản
prompt = """
Bạn là một đạo diễn và biên kịch chuyên nghiệp. 
Hãy xem video này và thực hiện các yêu cầu sau:
1. Tóm tắt nội dung chính và mô tả các phân cảnh/nhân vật trong video.
2. Tự viết một kịch bản video ngắn 60 giây (dạng TikTok/Reels) dựa trên ý tưởng này.
   Định dạng bảng gồm các cột: [Thời gian | Cảnh quay/Góc máy | Lời thoại/Voiceover | Âm nhạc/Hiệu ứng].
"""

# 5. Gọi Model gemini-3.6-flash để sinh kịch bản
response = client.models.generate_content(
    model="gemini-3.5-flash-lite", #gemini-3.5-flash-lite gemini-3.6-flash
    contents=[video_file, prompt]
)

print("\n=== KỊCH BẢN ĐƯỢC TẠO RA ===")
print(response.text)

# (Tùy chọn) Xóa file trên Cloud sau khi dùng xong
client.files.delete(name=video_file.name)